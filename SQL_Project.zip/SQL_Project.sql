create database if not exists SQL_Project;
use SQL_Project;

-- Publisher_table
CREATE TABLE if not exists publisher(
publisherName Varchar(255) primary key,
publisherAddress Varchar(255),
PublisherPhone Varchar(255));

select * from publisher;

-- Borrowers table
create table if not exists borrowers(
cardNo int primary key,
borrowerName varchar(255),
borrowerAddress varchar(255),
borrowerPhone varchar(255));

select * from borrowers;


-- Branch table
create table if not exists  Branch(
BranchID int auto_increment primary key,
BranchName varchar(255),
BranchAddress varchar(255));

select * from Branch;


-- Books Table
create table if not exists Books(
BookID int primary key,
BookTitle varchar(255),
BookPublisher varchar(255),
foreign key(BookPublisher) references Publisher(PublisherName)
ON delete cascade
ON update cascade);

select * from Books;


-- Authors Table
create table if not exists Author(
AuthorID Int primary key auto_increment,
Book_ID int,
AuthorName Varchar(255),
foreign key(Book_ID) references Books(BookID)
ON delete cascade
ON update cascade);

select * from Author;


-- Books Copies Table
create table if not exists Copies(
Copies_ID int primary key auto_increment,
CBookID int,
CBranchID int,
No_of_Copies Int,
foreign key(CBookID) references Books(BookID),
foreign key(CBranchID) references Branch(BranchID)
ON delete cascade
ON update cascade);

select * from Copies;


-- Books Loan Table
create table if not exists Loans(
LoansID int primary key auto_increment,
LBooksID int,
LBranchID int,
LCardNo int,
Dateout date,
datedue date,
foreign key(LBooksID) references Books(BookID),
foreign key(LBranchID) references Branch(BranchID),
foreign key(LCardNo) references Borrowers(cardNo)
ON delete cascade
ON update cascade);


select * from Loans;



-- How many copies of the book titled "The Lost Tribe" are owned by the library branch whose name is "Sharpstown"?
select Branchid, BranchName, BookID, BookTitle, No_of_Copies from Branch left join (select * from Books left join Copies on CBookid = BookID where BookTitle = 'The Lost Tribe') as book_copy on BranchID = CBranchID where BranchName = 'Sharpstown';


-- How many copies of the book titled "The Lost Tribe" are owned by each library branch?
select Branchid, BranchName, BookID, BookTitle, No_of_Copies from Branch left join (select * from Books left join Copies on CBookid = BookID where BookTitle = 'The Lost Tribe') as book_copy on BranchID = CBranchID;


-- Retrieve the names of all borrowers who do not have any books checked out.
select * from borrowers where CardNo not in (select LCardNo from Loans);


-- For each book that is loaned out from the "Sharpstown" branch and whose DueDate is 2/3/18, retrieve the book title, the borrower's name, and the borrower's address. 
select BookID, BookTitle, borrowerName, borrowerAddress, LCardNo, datedue, BranchName from Books inner join (select * from borrowers inner join (select * from Loans left join Branch on LBranchID = BranchID where LBranchID = 1 and datedue = '2018-02-03') as Loandue on LCardNo = CardNo) as borrowers_due on LBooksId = BookID;


-- For each library branch, retrieve the branch name and the total number of books loaned out from that branch.
select LBranchID, BranchName, count(*) as No_of_Books_Loaned_out from Loans left join Branch on LBranchID= BranchID group by LBranchID;

-- Retrieve the names, addresses, and number of books checked out for all borrowers who have more than five books checked out.
select CardNo, count(*) as No_of_Books_checked_out, borrowerName, borrowerAddress  from Loans left join borrowers on LCardNo = CardNo group by LCardNo having count(*) > 5 order by count(*);

-- For each book authored by "Stephen King", retrieve the title and the number of copies owned by the library branch whose name is "Central".
select BookID, BranchName, BookTitle, AuthorName, No_of_Copies from Branch inner join (select * from Copies inner join (select * from Books left join Author on Book_ID = BookID where AuthorName = 'Stephen king') as book_author on CBookID = BookID) as Copy_author on BranchID = CBranchID where BranchName = 'Central';


select count(*) from loans;
